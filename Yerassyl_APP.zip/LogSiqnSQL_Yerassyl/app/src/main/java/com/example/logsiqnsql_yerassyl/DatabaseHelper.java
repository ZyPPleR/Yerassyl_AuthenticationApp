package com.example.logsiqnsql_yerassyl;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import androidx.annotation.Nullable;
import android.util.Log;
public class DatabaseHelper extends SQLiteOpenHelper {

    public static final String databaseName = "Logs.db";

    public DatabaseHelper(@Nullable Context context) {
        super(context, "Logs.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase MyDatabase) {
        MyDatabase.execSQL("create Table users(email TEXT primary key, password TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase MyDB, int i, int i1) {
        MyDB.execSQL("drop Table if exists users");
    }

    public Boolean insertData(String email, String password){
        SQLiteDatabase MyDatabase = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("email", email);

        // Хеширую пароль перед сохранением
        String hashedPassword = PasswordHasher.hashPassword(password);
        contentValues.put("password", hashedPassword);
        long result = MyDatabase.insert("users", null, contentValues);

        if (result == -1) {
            return false;
        } else {
            return true;
        }
    }

    public Boolean checkEmail(String email){
        SQLiteDatabase MyDatabase = this.getWritableDatabase();
        Cursor cursor = MyDatabase.rawQuery("Select * from users where email = ?", new String[]{email});

        if(cursor.getCount() > 0) {
            return true;
        }else {
            return false;
        }
    }
    public Boolean checkEmailPassword(String email, String password) {
        SQLiteDatabase MyDatabase = this.getWritableDatabase();
        Cursor cursor = MyDatabase.rawQuery("SELECT * FROM users WHERE email = ?", new String[]{email});

        if (cursor.moveToFirst()) {
            int passwordColumnIndex = cursor.getColumnIndex("password");

            if (passwordColumnIndex != -1) {
                String storedHashedPassword = cursor.getString(passwordColumnIndex);

                // TEST database with Logging. (Логирую хеши для проверки)
                Log.d("DatabaseHelper", "Stored Hashed Password: " + storedHashedPassword);
                Log.d("DatabaseHelper", "Input Password: " + password);

                // Проверяю с использованием PasswordHasher
                boolean passwordMatches = PasswordHasher.checkPassword(password, storedHashedPassword);

                Log.d("DatabaseHelper", "Password Match: " + passwordMatches);

                return passwordMatches;
            }
        }

        return false;
    }
}