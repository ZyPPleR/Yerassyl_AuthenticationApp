package com.example.logsiqnsql_yerassyl;

import org.mindrot.jbcrypt.BCrypt;

public class PasswordHasher {

    private static final String STATIC_SALT = "$2a$10$t1k6psZi.d2s35BgoLzhze";

    public static String hashPassword(String password) {
        return BCrypt.hashpw(password, STATIC_SALT);
    }

    public static boolean checkPassword(String password, String storedHashedPassword) {
        return BCrypt.checkpw(password, storedHashedPassword);
    }
}
